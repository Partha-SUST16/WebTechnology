
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class Store {
    public static List<Owner>list = new ArrayList();
    public static void emni(){
        //String name, String brand, String model, int year, boolean using
        list.clear();
       // list.add(new Owner("abc","cdf","ghi",2010,true));
        //list.add(new Owner("jkl","mno","pqr",2010,true));
    }
}
